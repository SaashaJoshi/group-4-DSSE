# stm32mp157c-odyssey-npi-tf-a
stm32mp157c-odyssey-npi-tf-a source code
