# Deeplearning
#this is just basic operations
