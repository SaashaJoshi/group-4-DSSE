# QuantumData

The project collects 18 quantum programs which are selected from 76 programs on Github by the steps as follow: (The file basic_arithmetic.py has two sections of code with different functions )

 (1) The quantum circuit structures are correctly supported by the quantum cloud platform.
 
 (2) If the quantum circuit uses a structure that is not supported by the quantum cloud platform, we attempt to replace the complex quantum gate with the equivalent of the supported quantum gate. 
 
 (3) If the structure cannot be replaced or the scale after replacement changes too much, the quantum circuit will be only used in the quantum simulator or abandoned. 
 
 (4) If a quantum circuit still does not work properly for some reason (running time is too long, requiring too much computing resource, etc.), it will be excluded. 
