# QuantumProgramming
Exercises, Tasks, and Projects for the Course on Quantum Programming
