QCPANOP
-------
A panoply of quantum chemistry codes for the autodidact in all of us.