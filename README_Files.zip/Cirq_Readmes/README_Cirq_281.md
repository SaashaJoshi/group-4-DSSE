# hlq
Hyahatiph Labs quantum computing research repository

## Getting started

Setup [cirq](https://quantumai.google/cirq/install) from Google
* Recommend using a Debian-based Linux distro
* Run `test.py` to verify the installation

The notebook `.ipynb` files require [Jupyter](https://jupyter.org)
* Install with `pip install jupyter`
* run `jupyter notebook`
