# QuantumMachineLearning
QUANTUM MACHINE LEARNING WORKSHOP Repo

Agenda for the workshop:

	- Introduction to Quantum computing.
	- Industry Leading Frameworks a review.
	- Basics of terminology and concepts in Quantum computing.
	- Programming your first circuit with practical's.
	- Gates Introduction with practical's.
	- Introduction to Tensorflow Quantum - Hybrid quantum machine learning framework.
	- Quantum Neural Network
	- Practical demonstration of end to end machine learning with tensorflow quantum.

Pre-requisite:
	- Introduction to Python
	- Introduction to Machine learning with practical knowledge would be added advantage.

Looking forward to have a interactive learning experience on the advancement in the quantum machine learning.

Presented by:

PRASANNA VENKATESH.J  (AI and Cloud Evangelist).
Linked In: https://www.linkedin.com/in/prasanna-venkatesh-jayaprakash/ 
