# Quantum-Programming-QNickel-Qiskit

About Tutorials and programming exercises for learning Quantum Computing by QNickel.

![image](https://user-images.githubusercontent.com/5441882/175547098-ae4c7c84-bee9-40bc-bf7e-06fff03451fa.png)

![image](https://user-images.githubusercontent.com/5441882/200410475-59745432-588e-4e98-bef7-5d6e36c449d8.png)


https://gitlab.com/qworld/nickel
