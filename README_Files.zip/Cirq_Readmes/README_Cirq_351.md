# PIRQ_Draft

Test before publishing anything in real Repo. at SRI International.

## Outline

PIRQ (Practical Intermediate Representation for Quantum)

Main objective is create open-source compiler desing process tutorials for Quantum computers. This tutorials will consist 4 Modules which are:

**Module 1** -> Classical computers intermediate representations (IR) tutorials and explanations

**Module 2** -> Quantum computers intermediate representations (IR) tutorials and explanations

**Module 3** -> Hybrid (Classical & Quantum) computers intermediate representations (IR) tutorials and explanations

**Module 4** -> Creating a full stack Quantum computing system example with chosen type of Quantum computers
