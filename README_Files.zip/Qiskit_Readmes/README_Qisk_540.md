# greens-function

Evaluating Green's functions on quantum computers.
Code pulled from [this](https://gitlab.com/huynh-alex/greens-function) Gitlab repository.
