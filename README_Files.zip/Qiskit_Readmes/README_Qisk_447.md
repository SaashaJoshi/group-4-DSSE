# qportfolio
Portfolio of quantum computing

To use this web app, follow the step:

1. Download this repository
2. Enter to this repository using the console
3. Write in the console the following line: python3 app.py
4. Copy the following text in the browser: http://127.0.0.1:5000/

