# QFT-Anhang

Für die drei erläuterten Frameworks sind drei Ordner mit den simplen QFT-Beispielen hier verfügbar:
* QISKIT: Juypter-Notebook (am besten über https://lab.quantum-computing.ibm.com replizieren, persönlicher Token ist dort automatisch abgelegt)
* CIRQ: Google Colab hier https://colab.research.google.com/drive/1xzZHUP3MVXwaZF65OHTi8YfAnGncTcML?usp=sharing
* Q#: .qs und .csproj-Files (am besten über Visual Studio replizieren, in Terminal über 'dotnet run' laufen)

Genauere Erläuterungen sind im Artikel angefügt.
