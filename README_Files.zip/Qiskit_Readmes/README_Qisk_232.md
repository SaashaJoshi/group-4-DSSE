Hello, I'm Hejia Qiu (Henry), a Ph.D candidate in computer science, also interested in programming and video game. This is my personal Github Pages, based on [this repository](https://github.com/academicpages/academicpages.github.io), and released under the MIT License. See LICENSE.md.

I will introduce my academic and general work in this website, including academic publication and tech & life blogs, generally in English and/or Chinese.

Feel free to contact me by any link in [my website](https://henryjaqiu.github.io/) if interested, including Email, Linkedin, ResearchGate, Steam...

### See 'Guide' in [my website](https://henryjaqiu.github.io/) if you wanna build a similar one.


