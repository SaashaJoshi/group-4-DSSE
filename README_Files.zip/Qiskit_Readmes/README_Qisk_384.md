# Qcg-project
I have implemented the famous Grover's Search algorithm whose time complexity is around O(sqrt(N)) where N is size of the input 
to find the all possible solutions of the famous dinner party problem. I use both statevector and qasm simulator to show the results and 
build the oracle using diagonal operators according to the given problem  to implement the grover's algo. Qiskit,numpy,matplotlib are some 
of the packages I have used and I have coded in the python language.
