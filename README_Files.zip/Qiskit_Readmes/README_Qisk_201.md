# QuantML
GitHub for Senior Design Project - Sean, Nathan, Keegan, Nolan, Akul & Kyle

Final iteration of our Jupyter notebook is in QuantML/QuantumComputing/4.8.21.ipynb

There are instructions in the README to run our notebook on a live webserver and see results for yourself. Cheers!
