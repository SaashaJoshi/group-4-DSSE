#ICPC-Quantum-Challenge-2021
From February 24th to 28th,2021, nearly 240 college students and alumni from across the globe competed to build the most efficient quantum circuits for solving mathematical problems using IBM Quantum and Qiskit as a part of the International Collegiate Programming Contest’s first ever Quantum Computing Challenge, powered by IBM Quantum and Qiskit.
