# QuanTech
QuanTech Workshop on Accelerated Ab Initio Molecular Dynamics
