# Space-Invasion-Research[WIP]
An experimental, straight-forward, terminal-based quantum computer game which runs on Qiskit Quantum simulator as of now.
