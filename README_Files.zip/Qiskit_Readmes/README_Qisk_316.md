# Programming-Evolution

This repo will record all the code that I have ever coded. 

The code come from the courses in my university or the internet that learned by myself, this will record what I revolute in the coding skill and how my computer science trip develop.


# The course in NCU: 

## Atmospheric major:

* ### [AP2039 - Atmospheric Instrumentation and Observation Ⅰ](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/AP/AP2039)
* ### [AP2049 - Computer Programming and Graphics I](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/AP/AP2049)
* ### [AP2050 - Computer Programming and Graphics II](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/AP/AP2050)
* ### [MA1003 - Calculus](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/MA/MA1003)
* ### [MA1004 - Calculus](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/MA/MA1004)
* ### [PH1031 - General Physics A](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/PH/PH1031)
* ### [PH1032 - General Physics A](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/PH/PH1032)
## Computer Science major: 

* ### [CE1001 - Introduction to Computer Science I](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE1001)
* ### [CE1002 - Introduction to Computer Science Ⅱ](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE1002)
* ### [CE1003 - Introduction to Computer Science I Lab](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE1003)
* ### [CE1004 - Introduction to Computer Science Ⅱ Lab](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE1004)
* ### [CE2004 - Principles of Programming Languages](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE2004)
* ### [CE2008 - Digital Design](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE2008)
* ### [CE2010 - Experiment of Digital Design](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE2010)
* ### [CE3005 - Algorithmics](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/CE/CE3005)

## General Studies

* ### [GS3073 - Introduction to Artificial Intelligence](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/GS/GS3073)
* ### [GS4519 - Introduction to machine learning](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/GS/GS4519)
* ### [GS4521 - Artificial Intelligence and Commercial Applications](https://github.com/1chooo/Programming-Evolution/tree/main/NCU/GS/GS4521)
# The course in NTU: 

* ### [BME5706 - APPLICATIONS OF MATLAB ON ENGINEERING](https://github.com/1chooo/Programming-Evolution/tree/main/NTU/BME5706)
* ### [EE5184 - Machine Learning](https://github.com/1chooo/Programming-Evolution/tree/main/NTU/EE5184)
