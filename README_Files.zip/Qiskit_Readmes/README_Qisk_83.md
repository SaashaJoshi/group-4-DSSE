# quantum-aia
NEQR Project Presentation for Summer 2021 BWSI Quantum

Presentation Links:
- Video: https://youtu.be/BREA7VcSncY
- Slides: https://docs.google.com/presentation/d/1UcNLYbaREBbMsRjwlUGm0GK_CUDiKmPKNIUiOoMOuRo/edit?usp=sharing

Many thanks to our course instructors Joe Clapis and Richard Preston, along with our TAs: Filip, Mridul, and Christopher!
