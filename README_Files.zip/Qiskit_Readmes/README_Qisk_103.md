# $T_{1\rho}$

A locker for spin-locking experiments. $T_{1\rho}$ currently supported. 

To see the full workflow of running the experiment, see the T1rho_experiment.ipynb file.

