<p align="left">
<img src="qiskittens.jpg" width="500" /> 
</p>
QEC Hackation 2022. IBM optimization challenge.
