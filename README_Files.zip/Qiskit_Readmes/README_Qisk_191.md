# Quantum-Wordle-Solver
Entangled_Pirates' project for QHack 2022 Open Hackathon
