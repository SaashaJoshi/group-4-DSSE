# Quantum-computing using qiskit


A 'quantum' notebooks version of IBM's quantum computer.

Done as part of Chris Ferrie's Introduction to Quantum Computing course at UTS.
