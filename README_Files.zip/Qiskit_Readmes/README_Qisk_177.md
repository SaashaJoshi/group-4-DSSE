# Research Project
A research project that tries to understand the current state of Dockerfiles on GitHub in terms of smells

Project continued in [this repository](https://github.com/VladCroitoru/dockerfile_smells).
