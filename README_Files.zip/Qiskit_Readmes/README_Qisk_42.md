# Bachelor Thesis

Code produced for bachelor thesis: Machine learning for classification with a quantum computer

This repository is archived.
