# Quantum-Qbit-workbook-1
Experiment about entanglement with Jupyter Notebook / Teleport Information between Qbit  
Most used Quantum Algorithms tested and experiments about machine learning
