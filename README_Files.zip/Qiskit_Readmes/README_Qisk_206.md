# Quantum_computing


[<img src="https://user-images.githubusercontent.com/39042676/168801248-faae90c5-1857-4aba-9471-b372d9a86924.gif" align="right" width="110">](https://en.wikipedia.org/wiki/Quantum_computing)

Quantum computing is a kind of computing that employs the properties of Quantum Mechanics, like Superposition, Entanglement, Interference, to perform computation.These speedups are possible due to the quantum mechanical. 



Bell State



