# Quantum Computer Systems Lecture Series
Welcome, we will put the slides in this repo for reference!

Signup for future zoom lectures: http://eepurl.com/h5O0Az

Youtube Channel: https://www.youtube.com/channel/UCneFmMm3v2DkyHqUeXhLY0w

Bilibili: https://space.bilibili.com/1982029406


Organizers: 

Zhiding Liang (https://zlianghahaha.github.io/)

Hanrui Wang (https://hanruiwang.me)


Website: 

Lecture Website: https://sites.nd.edu/quantum/

Useful Quantum Machine learning Website: https://qmlsys.mit.edu/



