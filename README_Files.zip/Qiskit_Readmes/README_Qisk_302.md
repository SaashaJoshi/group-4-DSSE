# QW-Nu_bit
Quantum Winter Hackathon
