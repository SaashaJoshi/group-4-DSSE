# QuantumMul



The multiplication is done by performing b times the addition of a.
Encoding  a in qubits and since the value of b is used only to know how many times it's  needed
to repeat the addition of a, I  decided not to transform it in a quantum
register but to keep it as a normal integer.


Tried a lot of methods other than this, this one seemed to work better for all cases of inputs.
