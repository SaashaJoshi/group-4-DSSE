# Qiskit-Fidelity
Fidelity : Provides the information of the Quantum states closeness

Types of Fidelity:
1. State fidelity
2. Process fidelity
3. Average Gate fidelity
4. Hellinger Fidelity: Realted to the closeness between the counts of the quantum probability distribution
