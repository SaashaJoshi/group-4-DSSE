# semester-6
Contains work related to Computer Graphics , Quantum Computing , Theory of Computation, Predictive analysis using stats and Ai applications.
