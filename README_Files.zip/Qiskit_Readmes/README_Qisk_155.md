# Qiskit-Global-Summer-School
Qiskit Global Summer School 2021 was focused on Quantum Machine Learning 
where various optimization and machine learning problems had been solved in
Quantum Gate Model using Qiskit.
The respositories contain code of all the five problem that we have solved 
in Quantum Gate Model using Qiskit.
