# ADAPT
Source code for the paper "ADAPT: Mitigating Idling Errors in Qubits via Adaptive Dynamical Decoupling" -MICRO 2021
