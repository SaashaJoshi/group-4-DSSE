# Quantum-Programming-Exps

This repository is my personal stash of Quantum programming.

## Install dependencies

Qiskit is the main library used to interact with quantum computers

### System dependencies

```sh
sudo apt install python3-dev python3-pip
```

### Python dependencies

```sh
pip3 install -r requirements.txt
```
