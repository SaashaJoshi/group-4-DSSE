# Womanium_2022_other_challenge

## team name: Schrodinger's kittens 
team member: Tan Jun Liang
- [ ] [Green Qupermarket - Technical Focus (Deloitte)](https://github.com/womanium-quantum/Green-Qupermarket-Technical-Focus---Deloitte)ready to start✅
- [x] [Quantum Natural Language Processing with lambeq (Quantinuum)](https://github.com/womanium-quantum/Quantum-Natural-Language-Processing-with-lambeq---Quantinuum)need to write a report. finish first overview, can proceed going deeper in custom ansatz for better accuracy, try different reader and better rewriting, Can QNLP offer the possibility to build interpretable systems? Or just start write a report about it. ✅
- [x] [Digital-analog Variational Quantum Eigensolver (IQM)](https://github.com/iqm-finland/iqm-academy-womanium-hackathon-DAQC-VQE)complete task to get full score.

experience: one of the worse hackathon ever, team member all disapear with no response.

My own opinion:  
Hackathon its self, overall is worthless compare to other hackathon, but is a good place for finding jobs related to quantum, and understand different problem. 
I would definitly rather choose QHack, QCHack, iQuHack, because of the prize, swag, and everything is just better.
