# Cloud_QAOA
I've included here code which I can then upload onto a google cloud virtual machine instance. 
