<!--
**mickahell/mickahell** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

<h1 align="center">Hi there, I'm Michaël <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" height="32" /></h1>

## I'm system engineer and Qiskit Advocate
I create quantum autom processes and tools for IT engineering.

#### You can find a live version of (almost) each of my project in my website --> https://xtraorbitals.xyz 

- 🔭 I’m currently working on Quantum computing
- 🌱 I’m currently learning how to create robot using Quantum computer
- 👯 I’m looking to collaborate on Quantum projects and paper experiments

---

<img align="left" alt="Qiskit" width="26px" src="https://raw.githubusercontent.com/AkashGutha/Qiskit-Snippets/master/assets/qiskit.gif" />
<img align="left" alt="Python" width="26px" src="https://cdn3.iconfinder.com/data/icons/logos-and-brands-adobe/512/267_Python-512.png" />
<img align="left" alt="Go" width="32px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Go_Logo_Blue.svg/2560px-Go_Logo_Blue.svg.png" />
<img align="left" alt="Docker" width="26px" src="https://cdn3.iconfinder.com/data/icons/social-media-2169/24/social_media_social_media_logo_docker-1024.png" />
<img align="left" alt="Streamlit" width="30px" src="https://docs.streamlit.io/logo.svg" />
<img align="left" alt="Linux" width="26px" src="https://cdn3.iconfinder.com/data/icons/logos-brands-3/24/logo_brand_brands_logos_linux-1024.png" />
<img align="left" alt="Electronic" width="32px" src="https://cdn4.iconfinder.com/data/icons/colorful-electronic-parts/108/circuitdiagram_full_of_color2-42-512.png" />
<img align="left" alt="Arduino" width="34px" src="https://upload.wikimedia.org/wikipedia/commons/8/87/Arduino_Logo.svg" />  
<br />
<br />

### Keep connect
[![GitHub](https://raw.githubusercontent.com/mickahell/mickahell/main/resources/github.png)](https://github.com/mickahell) 
[![LinkedIn](https://raw.githubusercontent.com/mickahell/mickahell/main/resources/linkedin.png)](https://www.linkedin.com/in/michaelrollin/) 
[![Twitter](https://raw.githubusercontent.com/mickahell/mickahell/main/resources/twitter.png)](https://twitter.com/mickahell89700)
