# Complex-Valued-Quantum-Neural-Networks
Attempt at making Complex Valued Neural Networks using Bayesian Inference and Quantum Computing technology

I am currently adding in new projects on this, in particular on complex valued Bayesian networks to see what happens if these are combined, with ideally
both Quantum Computing Technology and Complex Manifolds.

Permission here is granted to use, modify or distribute the resources I have shown here, provided that I am given credit for the work in which I have done.

Thomas Nathaniel Toseland.

P.S. I would like to offer due credit to the original authors when appropriate, and I have attempted to link that information into the relevant files here.
