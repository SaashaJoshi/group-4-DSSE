# QCL_2021
My quantum circut lerning project.
Here is Article about it:

https://docs.google.com/document/d/1goLmh9o-xA6nhoic9ij4tMGfYh4H2zuz2Tqk9wzU9iA/edit?usp=sharing 

Simple classificator.
