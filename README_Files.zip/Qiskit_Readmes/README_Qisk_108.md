# Quantum Subteam - Spring 2021
A project to optimize quantum circuits on arbitrary architectures using game AI.
