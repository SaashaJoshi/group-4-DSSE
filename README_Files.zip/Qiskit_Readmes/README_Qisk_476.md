# Quantum_Economics
Gathers data and programs developed at University of Waterloo

Here I show the codes and some data used for the Risk Evaluation,
Quantum Classification and Transactions Optimization.
