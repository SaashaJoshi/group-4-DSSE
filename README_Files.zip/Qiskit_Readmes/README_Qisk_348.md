# Team-Quanta
Quantum Winter Hackathon 2020


Team Members

Zulker Nayeen Nahiyan

Kusal Mahendra Abeywickrama

Shah Ishmam Mohtashim(Captain)




