# sc_bebop
Repository for submitting jobs on the cluster

This repository is for sharing the files to be submitted on the cluster. 
Folder ac.jiang should contain prevois work files(files before 09/01/2022).
