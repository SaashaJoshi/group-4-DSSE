# Variational-Quantum-Eigensolver

## Devlog

### 7/26/22
#### Nathan
- Test

#### Zeel
- Zeel's Test

### 7/27/22
#### Zeel
- Second Test

### 7/28/22
### Jason
- Test