# ibm-quantum-challenge-fall-2021

[![Image from Gyazo](https://i.gyazo.com/6f20f54eee200fcfd64a6db853922357.png)](https://gyazo.com/6f20f54eee200fcfd64a6db853922357)
