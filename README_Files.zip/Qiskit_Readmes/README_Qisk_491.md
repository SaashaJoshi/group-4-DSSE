[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/jorgevazquezperez/Quantum-image-classifier.git/main?labpath=docs%2FUsageTutorial.ipynb)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

# Quantum image classifier
