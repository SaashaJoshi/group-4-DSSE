<h4 align=center><b> INTEGER FACTORIZATION USING SHOR'S ALGORITHM<br /> AND ITS IMPLEMENTATION ON A QUANTUM COMPUTER</b><br /><br />
A Project Work Submitted to<br />
 DEPARTMENT OF PHYSICS<br />Khwopa College<br />(
 affiliated to Tribhuvan University)<br />Dekocha-6, Bhaktapur<br />
 In the Partial Fulfillment of the Requirements for the Award of<br />
 Degree of<br />B.Sc in Physics<br />By<br />
 <b>Aman Ganeju</b></h4>
