# comp-phys
Introduction to Computational Physics

Online Textbook for Computational Physics Cource PH423 based on Jupyter Book.

