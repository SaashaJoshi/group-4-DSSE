# Julia_Juqbox
This is the code for Applied Math-Summer Undergrad Research Experience project. All the codes and weekly notes are available.
