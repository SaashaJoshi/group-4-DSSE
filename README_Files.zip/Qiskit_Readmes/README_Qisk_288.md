# Quantum-Leverage-100x
양자정보경진대회

## Set Up
```bash
conda env create --file conda_env.yaml
conda activate ql100x
python QMCpricing.py
```
