Quantum Computing for Energy optimization

1. Solving Knapsack Problem for Energy Market Auction Mechanism using IBM Qiskit
2. Solving Fault detection in Energy Models using Warm Start QAOA.
(Major report available as PDF)
