# HHL

Base on HHL algorithm in qiskit, rewrite the HHL algorithm code for educational perpose.

HHL 알고리즘을 qiskit의 함수에 기반해서 다시 작성하여 원리에 대해 이해를 도움
