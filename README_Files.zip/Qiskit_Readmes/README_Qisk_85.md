# quantum-computing
Contains all exercises and projects undertaken during the course of learning the various frameworks to program on quantum computers.
