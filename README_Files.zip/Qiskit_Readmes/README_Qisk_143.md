# Quantum-Computing-Workshops

![image](https://user-images.githubusercontent.com/5441882/178162055-a2652743-08c0-48fc-bf0d-c268529dafa2.png)

<h4> This repository consists of homework questions from quantum computing beginner workshop programs. </h4>

<li> Quantum Number Random Generator </li>
<li> Half Adder </li>
<li> Full Adder </li>
<li> Grover's Algorithm </li>
<li> Super-dense coding </li>
 
