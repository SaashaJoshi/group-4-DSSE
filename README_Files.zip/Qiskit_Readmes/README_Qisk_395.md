# Quantum-Computing
These are the assignment for Introduction for Introduction to Quantum Computing: Quantum Algorithms and Qiskit.
(https://onlinecourses.nptel.ac.in/noc21_cs103/course).
The files are fully solved, clarified and discussed by Mentors team of the course on Discord.
Note - The notebooks require qiskit to be installed in your local machine, or you can run them on the IBM cloud (quantum-computing.ibm.com)
