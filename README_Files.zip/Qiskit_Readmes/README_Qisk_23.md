### Quantum Computing ###
Based on a Spring 2022 ISE REU by Houd Hassani
* houdh2@illinois.edu
* https://www.linkedin.com/in/houd-hassani-0005101aa/

Project director: Richard Sowers
* <r-sowers@illinois.edu>
* <https://publish.illinois.edu/r-sowers/>

Copyright 2022 University of Illinois Board of Trustees. All Rights Reserved. Licensed under the MIT license

### Explanation of repository:
This repo contains an exploration of qiskit.  The different QiskitExploration_XXX.ipynb notesbooks are an exploration of the appropriate functions in qiskit.
