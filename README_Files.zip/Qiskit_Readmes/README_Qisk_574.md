# 409Project
## Prepared: 
1. pip install qiskit[0.24.0]  (New version is not work in some cases)
2. sudo apt-get install python3-tk
3. sudo apt-get install python3-pil python3-pil.imagetk
4. pip install qrandom

## Run the program
python3 init.py

## Reference
### Ideas
Catsweeper (https://github.com/desireevl/quantum-catsweeper)
Minesweeper
### Icons (https://www.iconfont.cn)

