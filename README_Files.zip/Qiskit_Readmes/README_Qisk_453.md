# qsof
qsof cohot 5
Task 2
With increase in depth of Encoder(ZZFeatureMap) circuit the train and test scores increases initially but with further increase the metrices start decreasing again
<br>
With increase in depth of Classifier Network (RealAmplitudes) circuit the train and test scores increases and found optimal at depth of 5.
<br>
A search mechanaism like grid search can be used to find the optimal depths of the encoder and classifier.
