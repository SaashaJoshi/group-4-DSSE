# permutevqe
We analyze how allocation of noisy, inhomogeneous qubits affects VQE.


Suppose you have a quantum computer with full connectivity, but the gates on different qubit pairs have different error rates. 
You would like to run VQE on this device, so you need to choose how to allocate qubits. That's what we consider here.

Runs with qiskit 0.38, might break with newer releases.
