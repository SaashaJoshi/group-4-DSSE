# Monica1998.github.io

Quantum Computation
-------------------

IBM Certified Associate Developer - Quantum Computation using Qiskit v0.2X

Resources:

Official Website: https://www.ibm.com/training/certification/C0010300#exam

Guide: http://www.primaryobjects.com/2021/09/15/the-ultimate-guide-to-a-quantum-computing-certification-with-qiskit/

Udemy Extra Practice Test

Extra Courses and Resources

https://www.amarchenkova.com/posts/best-quantum-computing-courses-online
https://quantumcomputing.stackexchange.com/questions/2667/currently-what-are-the-best-structured-courses-available-online-on-quantum-comp

OSCP
----

Start with Network+ & Security+





https://johnjhacking.com/blog/the-oscp-preperation-guide-2020/
https://www.netsecfocus.com/oscp/2021/05/06/The_Journey_to_Try_Harder-_TJnull-s_Preparation_Guide_for_PEN-200_PWK_OSCP_2.0.html#overview
https://infosecwriteups.com/how-i-passed-oscp-with-100-points-in-12-hours-without-metasploit-in-my-first-attempt-dc8d03366f33
https://blog.adithyanak.com/oscp-preparation-guide/resources
