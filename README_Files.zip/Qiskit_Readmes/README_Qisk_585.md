# quantum_simulator
A simulator to test out different quantum algorithms 

## Description

This is a simulator to test out different quantum algorithms.

## Usage

```bash
python quantum_simulator.py
```

