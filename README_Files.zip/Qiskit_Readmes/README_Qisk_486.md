# Resources developed for the Möller Group's Outreach activities

Project number 1:
"Computing with randomness"

Illustrations of the basic ideas behind Monte-Carlo
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/gunnarmoller/GroupOutreach/HEAD)
