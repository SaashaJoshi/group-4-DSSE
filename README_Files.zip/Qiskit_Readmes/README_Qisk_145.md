# Qiskit-India-Challenge
Repo for Qiskit India Challenge 2020
