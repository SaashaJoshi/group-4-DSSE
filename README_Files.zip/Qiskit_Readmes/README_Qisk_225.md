# Quantum_Qkrishi
- Summer '22 Quantum Intern
Part of Protein Folding Team

Guide: Prof. Raghavendra 

Topic: Simulating protein folding using quantum computer
