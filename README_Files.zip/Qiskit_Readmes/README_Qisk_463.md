# QC-Qiskit
En este repositorio iré añadiendo mis avances en computación cuántica así como diapositivas de mis charlas
