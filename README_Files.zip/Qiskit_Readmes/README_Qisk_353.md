# curso_computacion_cuantica
Notas propias para el cursos de introducción a la computación cuántica.
