# VQE
## The submission for the VQE project dated 1/06-14/06 '21
### Here are the details for the project https://github.com/qIndia/Techni-Q/blob/main/Project%201.md
