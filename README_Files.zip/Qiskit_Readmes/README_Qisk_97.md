# quantum-for-engineers

Explore Quantum Computing and Quantum Machine learning through code.
