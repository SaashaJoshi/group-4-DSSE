# Team-Grover-SAT-Code

2 Programs are included
The first program in file "k-SAT.py" is based on the Qiskit implementation of Grover's Algorithm to solve k-sat problems. It takes as input a SAT problem in dimac format in "test.dimacs"

A modified version in "limitation.ipynb" allows for the simulation of noise and imperfect gates in order to demonstrate the speedup from Grover’s Algorithm disappears for K-SAT problems with large K.

Thank You,
Team Grover SAT: Russell Epp, Long Tran, Joshua Malmberg, Kyle Zhu
