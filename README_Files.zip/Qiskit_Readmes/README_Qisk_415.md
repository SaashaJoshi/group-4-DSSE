This repo uses pre-defined Shor's algorithm of Qiskit in order to find prime factors of number N.
