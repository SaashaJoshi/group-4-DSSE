# psx-engine

Very messy code, I was still learning PSX programming and Psy-Q.

Might continue working on this at some point

https://www.youtube.com/watch?v=vJabq2l74bw
