# minDQN
A Minimal Deep Q-Network (minDQN)

Running this code will render the agent solving the CartPole environment using OpenAI gym. Our Minimal Deep Q-Network is approximately 150 lines of code. In addition, this implementation uses Tensorflow and Keras and should generally run in less than 15 minutes.

## Usage
```
python3 minDQN.py
```
