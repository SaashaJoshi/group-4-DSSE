# Exercism Q# Track

## Status

This track has no exercises and no work was done on it after the repository was created.

If you wish to work on this track, please post in the [Exercism Community Forum](https://forum.exercism.org/c/exercism/building-exercism/125) to discuss it with the team.
