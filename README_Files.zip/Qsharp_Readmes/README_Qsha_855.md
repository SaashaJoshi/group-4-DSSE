<div align="center">
    <img src="https://docs.adachi.top/images/adachi.png" width="200"/>
    <h3>- Adachi-GBOT -</h3>
    <div>
        <a href="https://docs.ethreal.cn" target="_blank">官方文档</a> &nbsp;|&nbsp;
        <a href="https://github.com/Extrwave/Adachi-Plugin" target="_blank">插件库</a>
    </div>
    <small>&gt; 原神Q频道助手 &lt;</small>
    <br>
    <small>&gt; 本项目为频道移植版 &lt;</small>
    <br>
    <small>&gt; 项目插件分离化 &lt;</small>    
    <br>
    <small>&gt; 请前往插件库安装对应插件 &lt;</small>
    <div>
        <br/>
        <a href="https://qun.qq.com/qqweb/qunpro/share?_wv=3&_wwv=128&inviteCode=ZcZDq&from=246610&biz=ka ">~ Adachi-BOT交流频道 ~</a>
    </div>
</div>

<div align="center">
<br>
</div>


