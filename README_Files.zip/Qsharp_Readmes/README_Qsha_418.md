# MD2Practice
Transform markdown to practice for exercise.
## Features
- LinkedIn Practices from https://github.com/Ebazhanov/linkedin-skill-assessments-quizzes
- Save progress to local storage