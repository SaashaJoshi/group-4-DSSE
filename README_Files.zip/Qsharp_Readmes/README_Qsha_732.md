# Meetup-Q

# Schedule

## S1 主題

1. [讀書會介紹 & Git](https://github.com/meetup-q/meetup-q/blob/master/s1/introduction.md) - 分享人：[KuanHui Wu](https://github.com/kkuanhui)(2021/04/01)
2. [Terminal & Editor & IDE & Markdown](https://github.com/meetup-q/meetup-q/blob/master/s1/) - 分享人：[Kuanhui Wu](https://github.com/kkuanhui)(2021/04/08)
3. [第一個程式語言 - JavaScript, Python](https://github.com/meetup-q/meetup-q/blob/master/s1/)  - 分享人：[KuanHui Wu](https://github.com/kkuanhui)(2021/04/29)
4. [資訊與資料的火花 - Data Science Pyramid](https://github.com/meetup-q/meetup-q/blob/master/s1/data-science.md) - 分享人：[Leon Hua](https://github.com/kid50901)(2021/05/06)
5. [網際網路 - The Internet! Heard of it?](https://github.com/meetup-q/meetup-q/blob/master/s1/internet.md) - 分享人：[俞健](https://github.com/snake19840)(2021/05/13)
6. [遠端工作 - Remote Work](https://github.com/meetup-q/meetup-q/blob/master/s1/remote-work.md) - 分享人:[Kuanhui Wu](https://github.com/kkuanhui)(2021/05/27)
7. [網頁前端 - Everything you see is Frontend.](https://github.com/meetup-q/meetup-q/blob/master/s1/frontend-development.md) - 分享人：[KuanHui Wu](https://github.com/kkuanhui)(2021/06/03)
8. [網頁後端 - Website, you got the whole world support.](https://github.com/meetup-q/meetup-q/blob/master/s1/) - 分享人：[自願者]()
9. [資料庫門禁 - Place where data lives which should be locked.](https://github.com/meetup-q/meetup-q/blob/master/s1/) - 分享人：[自願者]()
10. [MVC 設計模式 - Model, View, Contorller]() - 分享人：[自願者](https://github.com/meetup-q/meetup-q/blob/master/s1/)



## S2 主題

S2 主題在 S1 結束之前與成員討論。
預計規劃
