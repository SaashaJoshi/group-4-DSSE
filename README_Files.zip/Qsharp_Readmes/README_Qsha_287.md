# Q&A
Q&amp;A Bareng Programmer Zaman Now, Orang Ganteng dan Intelek

## Cara Bertanya

- Silahkan submit pertanyaannya di bagian Issues di project ini
- Pastikan dulu tidak ada pertanyaan yang sama dengan yang lain, jika sama lebih baik vote pertanyaan yang sudah ada, jika tetep maksa bikin pertanyaan baru, maka pertanyaannya akan di close 
- Pertanyaan yang menarik, akan saya coba jawab dalam bentuk vlog, pertanyaan yang jawabannya sederhana akan saya jawab via Image Post (Instagram)
- Semua orang bisa ikut menjawab, feels free untuk kontribusi

## Daftar Pertanyaan Menarik

- Untuk pemula belajar pemrograman apa yang cocok? https://www.youtube.com/watch?v=vTtqtFtIzio
- Apa portofolio bagus untuk programmer? https://www.youtube.com/watch?v=fk5XDky9C0c&t=9s
- Gaji programmer di Indonesia bisa puluhan juta? https://www.youtube.com/watch?v=JFxdu50AEtM
- Lebih baik Fullstack atau Spesialis? https://www.youtube.com/watch?v=Cn5fLJIR2Vo
- Menangani Tipe Data Date Time dan TimeZone https://www.youtube.com/watch?v=nEOEvWm5yPA
- Apakah Lulusan Sosial Bisa Jadi Programmer? https://www.youtube.com/watch?v=wM_Zey4VM0w
- Apakah SOLID Wajib Digunakan? https://www.youtube.com/watch?v=4YIUo7ZMMlk
- Portofolio untuk DevOps https://www.youtube.com/watch?v=-6RVtfzOc1A
- Gaji Programmer di Indonesia vs Luar Negri https://www.youtube.com/watch?v=F1LJGaAHE7g
- Relasi Table One to One Kok Pisah Table https://www.youtube.com/watch?v=6xU8K_w7gN4
- Menghitung Resource Server untuk Aplikasi https://youtu.be/g0DXyEAqOko
- Trunk Based Development vs Git Flow https://youtu.be/jydxcnSOIG4
- Junior Programmer vs Senior Programmer https://youtu.be/PRK7RBFJ-p8
- Tips Menjadi Speaker di Acara Teknologi https://youtu.be/Tl2RA9Mxi7Q
- Backend Programmer Wajib Mengerti Low Level Programming? https://youtu.be/oJzHEAS_uPg
- Cara Upload File ke Server dengan Load Balancer https://youtu.be/89Ep6BUwbaI
- Cara Kerja Aplikasi Realtime https://youtu.be/w_rOM943vCw
- Apakah Linked List Gak Penting? https://youtu.be/CWcp-89gp6c
- Bikin Aplikasi Backend Dulu atau Frontend Dulu? https://youtu.be/wtYSFNJE3h8
- Validasi di Frontend atau Backend? https://youtu.be/sAiU2fc2qWY
- Struktur Folder Aplikasi https://youtu.be/tu6IKx_VXLA
- Buat Apa Dev Dependency? https://youtu.be/HvKeqSaC9GU
