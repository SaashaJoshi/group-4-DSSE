# qctrl-qchack--Quantum-Musketeers-
Q-CTRL QCHack Challenge &lt;Quantum_Musketeers> entry
