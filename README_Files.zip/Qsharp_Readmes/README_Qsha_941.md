<img alt="AppIcon" src="https://user-images.githubusercontent.com/52348220/164444909-37522368-942e-49fc-8e30-80ca99d5ad4e.png" width="128px" align="center" />

[![Platforms](https://img.shields.io/badge/Platforms-macOS-blue?style=flat-square)](https://apps.apple.com/app/id1591155142)
[![macOS](https://img.shields.io/badge/macOS-12.0-blue.svg)](https://developer.apple.com/macOS)
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Ftkgka%2FSwitcher&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)

# Switcher

<a href ="https://github.com/tkgka/Switcher/blob/main/Readme/README_KR.md" >KOR</a>


**press command + q twice to shutdown app**

![image](https://user-images.githubusercontent.com/52348220/150669417-04c33fc1-5780-4627-abf4-359eaa5a333c.gif)


**support Key mapping**

https://user-images.githubusercontent.com/52348220/164449012-04c86ff9-a26f-4b9a-b7e1-ef30d0e26f4d.mov


**change mouse Wheel direction**


## 💾 [Download](https://github.com/tkgka/Switcher/releases) 
[**Download the app**](https://github.com/tkgka/Switcher/releases/download/v2.0.6/Switcher.dmg)


check introduction <a href = "https://github.com/tkgka/Switcher/blob/main/Readme/HowToUse_EN.md"> here </a>

## Contect Me
ksh17171@gmail.com

<a href="https://www.buymeacoffee.com/tkgka" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>


