# Trading-Robot-Deep-Q-Learning

A Trading Robot developed in Python, using Deep Q Learning.

This code has a GPL License.

# Video

In my YouTube channel I explain how the code works, line by line.

🔗[YouTube Channel Link](https://www.youtube.com/channel/UCyBV38-6vCe7MBVXD5yxOOw)