# Nados Level-1 Q's in Leetcode
Nados Level 1 Q's in Leetcode : [List](https://bit.ly/3SSoz1y)                      
Created by me and @harsh vardhan
