## 데모실행
1. npm install
2. npm run start 
3. http://localhost:3000/qna.html 브라우저 확인


## API Mock server
1. npm install -g json-server
2. json-server --watch ./data-sources/db.json -p 3001
